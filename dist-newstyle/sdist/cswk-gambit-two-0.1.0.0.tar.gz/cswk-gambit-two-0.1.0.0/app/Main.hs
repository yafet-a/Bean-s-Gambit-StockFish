-- -- Define a type alias for our parser
-- type Parser = Parsec Void String

-- -- Define a parser for a single game square
-- gameSquareParser :: Parser GameSquare
-- gameSquareParser = choice
--   [ BlockSquare <$ char '#'
--   , EmptySquare <$ char '_'
--   , PlayerSquare <$> letterChar
--   ]

-- -- Define a parser for a single row of the game board
-- gameRowParser :: Parser [GameSquare]
-- gameRowParser = many gameSquareParser

-- -- Define a parser for the entire game board
-- gameBoardParser :: Parser GameBoard
-- gameBoardParser = do
--   rows <- many (gameRowParser <* eol)
--   return (GameBoard rows)

-- -- Define a parser for the entire game state
-- gameStateParser :: Parser GameState
-- gameStateParser = do
--   char '{'
--   board <- gameBoardParser
--   char '}'
--   return (GameState board)

-- -- Define a parser for the entire BGN file
-- bgnFileParser :: Parser BGNFile
-- bgnFileParser = do
--   gameState <- gameStateParser
--   return (BGNFile gameState)

module Main where 
  
import Bean.Types
import Bean.Game
import Text.Megaparsec
import Text.Megaparsec.Char
import System.FilePath
import System.Environment (getArgs)
import Data.Void (Void)
import qualified Data.Text as T

main :: IO ()
main = do
  args <- getArgs
  case args of
    [filename] -> do
      maybeBoard <- readBoard filename
      case maybeBoard of
        Just board -> print board
        Nothing -> return ()
    _ -> putStrLn "Please provide a BGN file name as an argument"


readBoard :: FilePath -> IO (Maybe Board)
readBoard filepath = do
  contents <- readFile filepath
  case parse parseBoard filepath contents of
    Left err -> do
      putStrLn $ "Error parsing " ++ filepath ++ ":"
      print err
      return Nothing
    Right board -> return $ Just board

parseBoard :: Parsec Void T.Text Board
parseBoard = do
  rows <- count 4 parseRow
  return rows

-- To avoid error of confusion with eol from Text.Megaparsec.Char
endOfLine :: Parsec Void T.Text ()
endOfLine = void $ char '\n' <|> eof

parseRow :: Parsec Void T.Text [Piece]
parseRow = do
  row <- count 4 parsePiece
  endOfLine
  return row

parsePiece :: Parsec Void T.Text Piece
parsePiece = choice
  [ char ' ' >> return Empty
  , char 'r' >> char 'c' >> return (Red Cow)
  , char 'b' >> char 'c' >> return (Blue Cow)
  , char 'r' >> char 'b' >> return (Red Bean)
  , char 'b' >> char 'b' >> return (Blue Bean)
  ]
